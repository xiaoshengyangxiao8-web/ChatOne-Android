# ChatOne（畅聊）Android 本地演示版

这是一个原生 Android Java 项目，不是网页套壳。应用使用 Android SDK 原生 View 构建，不依赖第三方 UI 框架。

## 当前功能
- 微信式四个主导航：微信、通讯录、发现、我
- 会话列表、会话搜索、发起聊天
- 本地文字聊天：发送消息、聊天记录持久化
- 通讯录好友列表及好友会话入口
- 朋友圈：查看动态、发布文字动态、点赞
- 个人中心和设置入口
- SharedPreferences 本地保存聊天和朋友圈数据
- Android 原生状态栏、导航栏和软键盘适配

## 构建 APK
需要安装 Android Studio（推荐最新版）及 Android SDK Platform 35。

1. 解压项目 ZIP。
2. Android Studio 选择 `Open`，打开 `ChatOne-Android` 文件夹。
3. 等待 Gradle Sync 完成。
4. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

命令行构建（需本机已安装 Gradle 和 Android SDK）：
```bash
gradle assembleDebug
```

## 重要说明
- 本版本是本地演示版，不具备跨设备联网通信、账号注册、云端同步、推送通知或真实语音/视频通话。
- 图片消息、语音消息、群聊管理和真实好友关系尚未实现。
- 当前所有示例联系人和动态均为虚构演示数据。
- 本项目未在此构建环境中编译或真机测试；请在 Android Studio 中完成 Gradle Sync 和 APK 构建后测试。
