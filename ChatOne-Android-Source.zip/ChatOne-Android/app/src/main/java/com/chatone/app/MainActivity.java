package com.chatone.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int GREEN = Color.rgb(7,193,96), BG = Color.rgb(247,248,250),
        TEXT = Color.rgb(25,30,35), MUTED = Color.rgb(145,151,158), LINE = Color.rgb(237,239,241);
    private LinearLayout root, content, bottom;
    private String tab = "微信", currentChat = null;
    private final ArrayList<JSONObject> chats = new ArrayList<>();
    private final ArrayList<JSONObject> moments = new ArrayList<>();
    private final String[] names = {"林小满","陈宇","产品讨论组","阿哲","妈妈","旅行搭子"};
    private final String[] initials = {"满","宇","产","哲","妈","旅"};
    private final String[] colors = {"#F0B58B","#8AB8D9","#85C7A5","#B59BD7","#E8A4A4","#E2C47C"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(247,248,250));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        loadData();
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private void space(LinearLayout l, int h) { View v = new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private void line(LinearLayout l) { View v = new View(this); v.setBackgroundColor(LINE); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(1)); p.leftMargin=dp(76); l.addView(v,p); }

    private void loadData() {
        android.content.SharedPreferences sp = getSharedPreferences("chatone",0);
        try {
            JSONArray a = new JSONArray(sp.getString("chats",""));
            for(int i=0;i<a.length();i++) chats.add(a.getJSONObject(i));
        } catch(Exception e) { seed(); }
        if(chats.isEmpty()) seed();
        try {
            JSONArray a = new JSONArray(sp.getString("moments",""));
            for(int i=0;i<a.length();i++) moments.add(a.getJSONObject(i));
        } catch(Exception ignored) {}
        if(moments.isEmpty()) seedMoments();
    }
    private void seed() {
        chats.clear();
        addChat("林小满","周末去海边吗？天气预报说会很好。","10:42",2,"#F0B58B");
        addChat("陈宇","收到，那个方案我看过了。","09:18",0,"#8AB8D9");
        addChat("产品讨论组","你：我晚点把原型发群里","昨天",5,"#85C7A5");
        addChat("阿哲","[动画表情]","昨天",0,"#B59BD7");
        addChat("妈妈","记得按时吃饭，别熬夜。","周一",1,"#E8A4A4");
        addChat("旅行搭子","机票已经订好啦 ✈️","周日",0,"#E2C47C");
        save();
    }
    private void addChat(String name,String msg,String time,int unread,String color) {
        try { JSONObject o=new JSONObject();o.put("name",name);o.put("last",msg);o.put("time",time);o.put("unread",unread);o.put("color",color);o.put("messages",new JSONArray());chats.add(o); }catch(Exception ignored){}
    }
    private void seedMoments() {
        try {
            JSONObject a=new JSONObject();a.put("name","林小满");a.put("avatar","#F0B58B");a.put("time","今天 10:20");a.put("text","生活需要一点小小的期待。周末去看海吧 🌊");a.put("likes",12);a.put("comments",3);moments.add(a);
            JSONObject b=new JSONObject();b.put("name","陈宇");b.put("avatar","#8AB8D9");b.put("time","昨天 18:45");b.put("text","新的一天，继续加油！☀️");b.put("likes",8);b.put("comments",1);moments.add(b);
        }catch(Exception ignored){}
        save();
    }
    private void save() {
        try {
            JSONArray a=new JSONArray();for(JSONObject o:chats)a.put(o);
            JSONArray m=new JSONArray();for(JSONObject o:moments)m.put(o);
            getSharedPreferences("chatone",0).edit().putString("chats",a.toString()).putString("moments",m.toString()).apply();
        }catch(Exception ignored){}
    }

    private void base(String title, String right, Runnable action) {
        root=col();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout bar=row();bar.setBackgroundColor(Color.WHITE);pad(bar,18,0,18,0);
        TextView t=text(title,20,TEXT,true);bar.addView(t,new LinearLayout.LayoutParams(0,dp(54),1));
        if(right!=null){TextView r=text(right,25,TEXT,false);r.setGravity(Gravity.CENTER);bar.addView(r,new LinearLayout.LayoutParams(dp(38),dp(54)));r.setOnClickListener(v->action.run());}
        root.addView(bar);
        content=col();root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void showHome() {
        currentChat=null;
        base(tab, tab.equals("微信")?"+":tab.equals("发现")?"＋":"", ()->{ if(tab.equals("微信")) newChatDialog(); else if(tab.equals("发现")) composeMoment(); });
        if(tab.equals("微信")) chatList();
        else if(tab.equals("通讯录")) contacts();
        else if(tab.equals("发现")) discover();
        else profile();
        nav();
    }
    private void nav() {
        bottom=row();bottom.setBackgroundColor(Color.WHITE);bottom.setElevation(dp(10));
        String[] labels={"微信","通讯录","发现","我"};String[] icons={"●","♙","◉","☺"};
        for(int i=0;i<labels.length;i++){
            final String name=labels[i];LinearLayout item=col();item.setGravity(Gravity.CENTER);
            TextView ic=text(icons[i],21,tab.equals(name)?GREEN:MUTED,true);ic.setGravity(Gravity.CENTER);
            TextView tx=text(name,10,tab.equals(name)?GREEN:MUTED,tab.equals(name));tx.setGravity(Gravity.CENTER);
            item.addView(ic);item.addView(tx);
            bottom.addView(item,new LinearLayout.LayoutParams(0,dp(55),1));
            item.setOnClickListener(v->{tab=name;showHome();});
        }
        root.addView(bottom);
    }
    private void avatar(LinearLayout parent,String name,String color,int size) {
        TextView a=text(name.length()>0?name.substring(0,1):"?",18,Color.WHITE,true);a.setGravity(Gravity.CENTER);
        try{a.setBackground(bg(Color.parseColor(color),12));}catch(Exception e){a.setBackground(bg(GREEN,12));}
        parent.addView(a,new LinearLayout.LayoutParams(dp(size),dp(size)));
    }
    private void chatList() {
        LinearLayout search=row();search.setBackground(bg(Color.rgb(239,241,243),9));pad(search,12,0,12,0);
        TextView st=text("⌕   搜索",14,MUTED,false);search.addView(st);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(38));sp.setMargins(dp(14),dp(10),dp(14),dp(10));content.addView(search,sp);
        search.setOnClickListener(v->searchDialog());
        ScrollView scroll=new ScrollView(this);LinearLayout list=col();scroll.addView(list);content.addView(scroll);
        for(JSONObject c:chats) {
            String name=c.optString("name"),color=c.optString("color","#85C7A5");
            LinearLayout r=row();pad(r,14,11,14,11);
            avatar(r,name,color,52);
            LinearLayout info=col();pad(info,12,0,0,0);
            LinearLayout top=row();TextView n=text(name,16,TEXT,true);top.addView(n,new LinearLayout.LayoutParams(0,dp(25),1));
            top.addView(text(c.optString("time"),11,MUTED,false));info.addView(top);
            LinearLayout bottomRow=row();TextView last=text(c.optString("last"),13,MUTED,false);last.setSingleLine(true);last.setEllipsize(android.text.TextUtils.TruncateAt.END);bottomRow.addView(last,new LinearLayout.LayoutParams(0,dp(23),1));
            int unread=c.optInt("unread");if(unread>0){TextView badge=text(unread>99?"99+":""+unread,10,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(Color.rgb(250,80,75),20));bottomRow.addView(badge,new LinearLayout.LayoutParams(dp(20),dp(20)));}
            info.addView(bottomRow);r.addView(info,new LinearLayout.LayoutParams(0,-2,1));list.addView(r);line(list);
            r.setOnClickListener(v->openChat(name));
        }
    }
    private void contacts() {
        EditText search=new EditText(this);search.setSingleLine();search.setTextSize(14);search.setHint("搜索联系人");search.setBackground(bg(Color.rgb(239,241,243),9));pad(search,12,0,12,0);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(42));p.setMargins(dp(14),dp(12),dp(14),dp(12));content.addView(search,p);
        String[] groups={"新的朋友","群聊","标签","公众号"};
        for(String g:groups) simpleRow(content,"＋",g,"",GREEN,()->toast(g+" · 演示功能"));
        TextView label=text("  好友",12,MUTED,true);pad(label,0,12,0,8);content.addView(label);
        for(int i=0;i<names.length;i++){final String n=names[i];simpleRow(content,n.substring(0,1),n,"",Color.parseColor(colors[i]),()->openChat(n));}
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){for(int i=0;i<content.getChildCount();i++){View v=content.getChildAt(i);if(v instanceof LinearLayout){Object tag=v.getTag();if(tag instanceof String)v.setVisibility(((String)tag).contains(s)?View.VISIBLE:View.GONE);}}}public void afterTextChanged(Editable e){}});
    }
    private void simpleRow(LinearLayout parent,String icon,String title,String sub,int color,Runnable click) {
        LinearLayout r=row();pad(r,16,10,16,10);TextView av=text(icon,16,Color.WHITE,true);av.setGravity(Gravity.CENTER);av.setBackground(bg(color,9));r.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout info=col();pad(info,12,0,0,0);info.addView(text(title,15,TEXT,false));if(!sub.isEmpty())info.addView(text(sub,11,MUTED,false));r.addView(info,new LinearLayout.LayoutParams(0,-2,1));parent.addView(r);r.setTag(title);line(parent);r.setOnClickListener(v->click.run());
    }
    private void discover() {
        simpleRow(content,"▣","朋友圈","分享生活中的精彩瞬间",GREEN,()->toast("朋友圈"));
        simpleRow(content,"⌕","扫一扫","",Color.rgb(78,164,135),()->toast("扫一扫为演示入口"));
        simpleRow(content,"♧","摇一摇","",Color.rgb(235,166,80),()->toast("摇一摇为演示入口"));
        simpleRow(content,"♡","看一看","",Color.rgb(238,111,124),()->toast("看一看为演示入口"));
        simpleRow(content,"⌁","搜一搜","",Color.rgb(83,150,208),()->toast("搜一搜为演示入口"));
        simpleRow(content,"♫","音乐","",Color.rgb(151,123,207),()->toast("音乐为演示入口"));
        TextView title=text("  朋友动态",12,MUTED,true);pad(title,0,18,0,8);content.addView(title);
        ScrollView sc=new ScrollView(this);LinearLayout list=col();sc.addView(list);content.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        for(JSONObject m:moments)momentCard(list,m);
    }
    private void momentCard(LinearLayout parent,JSONObject m) {
        LinearLayout card=col();pad(card,16,13,16,13);LinearLayout head=row();avatar(head,m.optString("name"),m.optString("avatar","#85C7A5"),42);
        LinearLayout who=col();pad(who,10,0,0,0);who.addView(text(m.optString("name"),14,GREEN,true));who.addView(text(m.optString("time"),10,MUTED,false));head.addView(who);card.addView(head);
        TextView body=text(m.optString("text"),14,TEXT,false);body.setGravity(Gravity.TOP);pad(body,52,10,0,10);card.addView(body);
        LinearLayout actions=row();pad(actions,52,0,0,0);TextView like=text("♡  "+m.optInt("likes"),12,MUTED,false);actions.addView(like,new LinearLayout.LayoutParams(0,dp(28),1));actions.addView(text("评论  "+m.optInt("comments"),12,MUTED,false));card.addView(actions);
        like.setOnClickListener(v->{try{m.put("likes",m.optInt("likes")+1);save();like.setText("♥  "+m.optInt("likes"));like.setTextColor(GREEN);}catch(Exception ignored){}});
        parent.addView(card);line(parent);
    }
    private void composeMoment() {
        EditText e=new EditText(this);e.setHint("这一刻的想法…");e.setMinLines(4);new AlertDialog.Builder(this).setTitle("发表朋友圈").setView(e).setNegativeButton("取消",null).setPositiveButton("发表",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){try{JSONObject m=new JSONObject();m.put("name","我");m.put("avatar","#07C160");m.put("time","刚刚");m.put("text",s);m.put("likes",0);m.put("comments",0);moments.add(0,m);save();showHome();}catch(Exception ignored){}}}).show();
    }
    private void profile() {
        LinearLayout hero=col();hero.setBackgroundColor(Color.WHITE);pad(hero,20,25,20,22);LinearLayout r=row();avatar(r,"我","#07C160",64);LinearLayout info=col();pad(info,15,0,0,0);info.addView(text("ChatOne 用户",20,TEXT,true));info.addView(text("账号：chatone_2026",12,MUTED,false));r.addView(info);hero.addView(r);content.addView(hero);
        space(content,12);
        simpleRow(content,"▤","服务与收藏","",Color.rgb(239,176,77),()->toast("服务与收藏"));
        simpleRow(content,"▣","卡包","",Color.rgb(86,151,205),()->toast("卡包"));
        simpleRow(content,"☺","表情","",Color.rgb(232,139,120),()->toast("表情"));
        space(content,12);
        simpleRow(content,"⚙","设置","账号、隐私与通用设置",Color.rgb(126,145,158),()->settings());
    }
    private void settings() {
        String[] opts={"个人资料","新消息通知","隐私","通用","关于 ChatOne"};
        new AlertDialog.Builder(this).setTitle("设置").setItems(opts,(d,w)->toast(opts[w]+" · 本地演示版")).setNegativeButton("关闭",null).show();
    }
    private void openChat(String name) {
        currentChat=name;JSONObject c=findChat(name);if(c==null){addChat(name,"打个招呼吧","刚刚",0,"#8AB8D9");c=findChat(name);save();}
        final JSONObject chat=c;try{chat.put("unread",0);}catch(Exception ignored){}save();
        root=col();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout bar=row();bar.setBackgroundColor(Color.WHITE);pad(bar,12,0,12,0);
        TextView back=text("‹",32,TEXT,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(38),dp(52)));back.setOnClickListener(v->showHome());
        TextView title=text(name,17,TEXT,true);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView more=text("···",22,TEXT,true);more.setGravity(Gravity.CENTER);bar.addView(more,new LinearLayout.LayoutParams(dp(38),dp(52)));root.addView(bar);
        ScrollView scroll=new ScrollView(this);LinearLayout messages=col();pad(messages,13,14,13,14);scroll.addView(messages);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        JSONArray existing=chat.optJSONArray("messages");
        final JSONArray arr;
        if(existing==null){arr=new JSONArray();try{chat.put("messages",arr);}catch(Exception ignored){}} else {arr=existing;}
        for(int i=0;i<arr.length();i++) addBubble(messages,arr.optJSONObject(i));
        LinearLayout composer=row();composer.setBackgroundColor(Color.WHITE);pad(composer,9,8,9,8);
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(14);input.setHint("发送消息…");input.setBackground(bg(BG,20));pad(input,14,0,12,0);
        composer.addView(input,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView send=text("发送",14,Color.WHITE,true);send.setGravity(Gravity.CENTER);send.setBackground(bg(GREEN,8));LinearLayout.LayoutParams sendp=new LinearLayout.LayoutParams(dp(56),dp(40));sendp.leftMargin=dp(8);composer.addView(send,sendp);root.addView(composer);
        send.setOnClickListener(v->{String value=input.getText().toString().trim();if(value.isEmpty())return;try{JSONObject msg=new JSONObject();msg.put("text",value);msg.put("mine",true);msg.put("time",System.currentTimeMillis());arr.put(msg);chat.put("messages",arr);chat.put("last","我："+value);chat.put("time","刚刚");save();addBubble(messages,msg);input.setText("");scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}catch(Exception ignored){}});
        input.setOnEditorActionListener((v,id,event)->{send.performClick();return true;});
        scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    }
    private JSONObject findChat(String name){for(JSONObject c:chats)if(c.optString("name").equals(name))return c;return null;}
    private void addBubble(LinearLayout parent,JSONObject msg) {
        if(msg==null)return;boolean mine=msg.optBoolean("mine");LinearLayout r=row();r.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);pad(r,0,5,0,5);
        TextView bubble=text(msg.optString("text"),14,TEXT,false);pad(bubble,12,9,12,9);bubble.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels*.72));
        bubble.setBackground(bg(mine?Color.rgb(149,236,105):Color.WHITE,8));r.addView(bubble);parent.addView(r);
    }
    private void newChatDialog() {
        final String[] choices=names;new AlertDialog.Builder(this).setTitle("发起聊天").setItems(choices,(d,w)->openChat(choices[w])).setNegativeButton("取消",null).show();
    }
    private void searchDialog() {
        EditText e=new EditText(this);e.setHint("搜索聊天或联系人");new AlertDialog.Builder(this).setTitle("搜索").setView(e).setPositiveButton("搜索",(d,w)->{String q=e.getText().toString();for(JSONObject c:chats)if(c.optString("name").contains(q)){openChat(c.optString("name"));return;}toast("没有找到相关联系人");}).setNegativeButton("取消",null).show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(currentChat!=null){currentChat=null;showHome();}else if(!tab.equals("微信")){tab="微信";showHome();}else super.onBackPressed();}
}
